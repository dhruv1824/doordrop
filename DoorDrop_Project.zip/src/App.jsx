// React + Tailwind Dropshipping Website Starter
import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const products = [
  {
    id: 1,
    name: "Minimalist Backpack",
    price: "₹1,299",
    image: "https://images.unsplash.com/photo-1510337550647-e84f83e341ca",
    seller: "UrbanGear Co."
  },
  {
    id: 2,
    name: "Wireless Earbuds",
    price: "₹2,499",
    image: "https://images.unsplash.com/photo-1585386959984-a4155224a1a6",
    seller: "SoundCore India"
  },
  {
    id: 3,
    name: "Desk LED Lamp",
    price: "₹799",
    image: "https://images.unsplash.com/photo-1604014237744-4b42f3b7fc0a",
    seller: "HomeGlow Decor"
  }
];

export default function Home() {
  const [cart, setCart] = useState([]);
  const [search, setSearch] = useState("");

  const addToCart = (product) => {
    setCart([...cart, product]);
  };

  const removeFromCart = (index) => {
    const newCart = [...cart];
    newCart.splice(index, 1);
    setCart(newCart);
  };

  const totalPrice = cart.reduce((sum, item) => {
    const price = parseInt(item.price.replace(/[^0-9]/g, ""), 10);
    return sum + price;
  }, 0);

  const filteredProducts = products.filter(p =>
    p.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="p-4">
      <h1 className="text-3xl font-bold mb-2">DoorDrop 🚪📦</h1>
      <p className="mb-4 text-gray-600">Your trusted dropshipping store. Pay online or COD 💸</p>
      <Input
        type="text"
        placeholder="Search products..."
        className="mb-6 max-w-md"
        value={search}
        onChange={(e) => setSearch(e.target.value)}
      />

      {/* Product Section */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {filteredProducts.map((product) => (
          <Card key={product.id} className="rounded-2xl shadow-xl">
            <CardContent>
              <img
                src={product.image}
                alt={product.name}
                className="w-full h-48 object-cover rounded-xl mb-2"
              />
              <h2 className="text-xl font-semibold">{product.name}</h2>
              <p className="text-sm text-gray-500 mb-1">Sold by {product.seller}</p>
              <p className="text-lg font-bold">{product.price}</p>
              <Button className="mt-2 w-full" onClick={() => addToCart(product)}>
                Add to Cart
              </Button>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Cart Section */}
      <div className="mt-10">
        <h2 className="text-2xl font-bold mb-4">Your Cart 🛒</h2>
        {cart.length === 0 ? (
          <p className="text-gray-500">Your cart is empty.</p>
        ) : (
          <div className="space-y-4">
            {cart.map((item, index) => (
              <div
                key={index}
                className="flex items-center justify-between p-4 bg-gray-100 rounded-xl shadow"
              >
                <div>
                  <h3 className="text-lg font-medium">{item.name}</h3>
                  <p className="text-sm text-gray-600">{item.price}</p>
                </div>
                <Button variant="outline" onClick={() => removeFromCart(index)}>
                  Remove
                </Button>
              </div>
            ))}
            <div className="text-right font-bold text-lg">
              Total: ₹{totalPrice}
            </div>
            <Button className="w-full bg-green-600 hover:bg-green-700">
              Place Order (Simulated)
            </Button>
          </div>
        )}
      </div>

      {/* Footer */}
      <footer className="mt-16 pt-8 border-t text-center text-sm text-gray-500">
        <p>&copy; 2025 DoorDrop. All rights reserved.</p>
        <p>
          Follow us on <a href="#" className="text-blue-500">Instagram</a> | <a href="#" className="text-blue-500">Contact Us</a>
        </p>
      </footer>
    </div>
  );
}
